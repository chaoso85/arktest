#!/bin/bash
sudo cp -v /usr/local/bin/perfnorm.pvid /usr/local/bin/perfnorm
sudo cp -v /usr/local/bin/perfmax.pvid /usr/local/bin/perfmax
sudo chmod 777 /usr/local/bin/perfnorm
sudo chmod 777 /usr/local/bin/perfmax
sudo cp /usr/local/bin/Set\ Launchimage\ to\ ascii\ or\ pic.sh /opt/system/
sudo cp /usr/local/bin/Set\ Launchimage\ to\ gif.sh /opt/system/
sudo rm /opt/system/Set\ Launchimage\ to\ vid.sh
printf "\033c" >> /dev/tty1
sudo systemctl restart emulationstation
